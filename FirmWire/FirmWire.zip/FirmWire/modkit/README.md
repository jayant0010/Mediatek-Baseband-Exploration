# FirmWire ModKit

Vendor-specific toolchains for creating injectable modules to extend baseband functionality. Folder names should match FirmWire vendor names.
