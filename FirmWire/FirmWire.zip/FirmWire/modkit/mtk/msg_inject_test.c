#include <task.h>
#include <modkit.h>
#include <hello_world.h>
#include "common.h"
#include "mtk_api.h"

#define PARA_STRUCT_SIZE 0xc
#define PARA_STRUCT_PLSIZE (PARA_STRUCT_SIZE-4)

#define TASK_ID_IDLE 0x3a7
#define TASK_ID_CC   0xb0
#define TEST_MSG_ID  0x25b

void real_main() {
    local_para_struct *_local_para_ptr;
    int taskIdIdle = 0x000;
    
    peer_buff_struct *_peer_buff_ptr = (void *)0;
    int response = 0;

int starti = 0;
int startj = 10;

    for(int i = starti; i <= 1000; i++) {
    	if(i % 100 != 60) {
			continue;  
		}
		if(i > starti) {
    		startj = 0;
    	}
    	for(int j = startj; j < 65536; j++) {
    		dhl_print_string(2, 0, 0, "Firmwire Debug **TEST_TASK_ID: %d\n", i);
    		dhl_print_string(2, 0, 0, "Firmwire Debug **TEST_MSG_ID: %d\n", j);
    		response = msg_send6(TASK_ID_IDLE, i, 0, j, _local_para_ptr, _peer_buff_ptr);
    		dhl_print_string(2, 0, 0, "Firmwire Debug RESPONSE: %d\n", response);
    	}
    }
    dhl_print_string(2, 0, 0, "Firmwire Debug RANGE TESTED\n");
}