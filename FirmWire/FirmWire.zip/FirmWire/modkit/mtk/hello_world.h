// Copyright (c) 2022, Team FirmWire
// SPDX-License-Identifier: BSD-3-Clause
#ifndef HELLO_WORLD_H
#define HELLO_WORLD_H

const char TASK_NAME[] = "testtask\0";

#endif
