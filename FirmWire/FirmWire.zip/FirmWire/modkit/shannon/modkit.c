// Copyright (c) 2022, Team FirmWire
// SPDX-License-Identifier: BSD-3-Clause
#define MODKIT_INSTANTIATE
#include <shannon.h>
