// Copyright (c) 2022, Team FirmWire
// SPDX-License-Identifier: BSD-3-Clause
#ifndef _TASK_H
#define _TASK_H

extern void task_main() __attribute__ ((noreturn));
void zero_bss();

#endif // _TASK_H
